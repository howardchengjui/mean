// import { Component } from '@angular/core';
// import { HttpService } from './http.service';
// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent {
//    title = 'app';
//    constructor(private _httpService: HttpService){}
//  }
import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  title = 'Mean';
  tasks : any;
  bulbasaur: any;
  abilities:any;
  pokeswithsameabil:any;
  thisTask:any;
  // pokemon:Array<any>;

  constructor(private _httpService: HttpService){
  
    // this.getBulbasaur()
    // this.getAllTasks()
    // this.getPokesWithSameAbilities()
  }

  getAllTasks(){
    let observable = this._httpService.getTasks()
    observable.subscribe( (data) => {
      // console.log(data)
      this.tasks=data
    })
  }

  showThisTask(id:String){
    let observable = this._httpService.getThisTask(id)
    observable.subscribe( (data) => {
      console.log(data)
      console.log(id)
      this.thisTask=data
    })
  }

  getBulbasaur(){
    let observable = this._httpService.getPokemon()
    observable.subscribe( (data) => {
      console.log(data)
      this.bulbasaur=data
  })
  }

  getPokesWithSameAbilities(){
    let observable1 = this._httpService.getPokemonsWithSameAbil()
    observable1.subscribe( (data) => {
      console.log(data)
      console.log(data['pokemon'].length)
  })
}

  }
//   onButtonClick(): void { 
//     console.log(`Click event is working`);
//   }
//   onButtonClickParam(num: Number): void { 
//     console.log(`Click event is working with num param: ${num}`);
//     // call the service's method to post the data, but make sure the data is bundled up in an object!
//     let observable = this._httpService.postToServer({data: num});
//     observable.subscribe(data => console.log("Got our data!", data));
// }

//   onButtonClickParams(num: Number, str: String): void { 
//     console.log(`Click event is working with num param: ${num} and str param: ${str}`);
//   }
//   onButtonClickEvent(event: any): void { 
//     console.log(`Click event is working with event: ${event}`);
//   }
