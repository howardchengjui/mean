const express = require("express");
const app = express();
app.get('/', (request, response) => {
   response.send("Hello Express");
});
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

app.get("/cats",function(req,res){
    res.render('cats')
})
app.get("/ragdoll",function(req,res){
    res.render('ragdoll')
})
app.get("/garfield",function(req,res){
    res.render('garfield')
})

app.use(express.static(__dirname + "/static"));
app.listen(8000, () => console.log("listening on port 8000"));